
function virarCD(element) {
    element.classList.toggle("virado");
}
function tocarTrecho() {
    alert("🎧 Tocando trecho da música...");
}
